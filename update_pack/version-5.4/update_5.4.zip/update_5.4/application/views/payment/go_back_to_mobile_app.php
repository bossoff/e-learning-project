<a class="btn btn-success w-100 text-left" href="<?php echo $this->session->userdata('app_url'); ?>" style="position: fixed;
    top: 0;
    left: 0;
    right: 0;
    z-index: 200;">
	<i class="fa fa-arrow-left"></i>  Go back to Mobile APP
</a>
<hr style="margin: 22px 0px; background-color: #ff000000;">